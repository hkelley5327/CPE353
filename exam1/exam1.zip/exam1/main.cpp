#include "dialog.h"
#include "ui_dialog.h"
#include <QApplication>
#include <QLabel>
#include <QtDebug>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;
    w.show();

    return a.exec();
}

